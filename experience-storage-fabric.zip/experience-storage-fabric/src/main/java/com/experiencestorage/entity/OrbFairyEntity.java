package com.experiencestorage.entity;

import com.experiencestorage.util.XpUtil;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/**
 * A small flying spirit. It floats around, slowly siphons experience from
 * players who get close, runs away when hurt, and drops everything it has
 * collected when it dies.
 */
public class OrbFairyEntity extends PathfinderMob {
    public static final int MAX_XP = 30970; // same as reaching level 100
    private static final double DRAIN_RANGE = 4.0;
    private static final int DRAIN_AMOUNT = 2;

    private int xp;

    public OrbFairyEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 20, true);
        setNoGravity(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 4.0)
                .add(Attributes.FLYING_SPEED, 0.1)
                .add(Attributes.MOVEMENT_SPEED, 0.1);
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation nav = new FlyingPathNavigation(this, level);
        nav.setCanOpenDoors(false);
        nav.setCanFloat(true);
        return nav;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new PanicGoal(this, 1.5));
        goalSelector.addGoal(2, new WaterAvoidingRandomFlyingGoal(this, 1.0));
        goalSelector.addGoal(3, new RandomLookAroundGoal(this));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!(level() instanceof ServerLevel serverLevel) || !isAlive()) return;

        // glowing trail so the fairy is visible
        if (tickCount % 3 == 0) {
            serverLevel.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 0.25, getZ(), 2, 0.15, 0.15, 0.15, 0.0);
            serverLevel.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 0.25, getZ(), 1, 0.1, 0.1, 0.1, 0.0);
        }

        // slowly siphon experience from the nearest survival player
        if (tickCount % 20 == 0 && xp < MAX_XP) {
            Player player = serverLevel.getNearestPlayer(this, DRAIN_RANGE);
            if (player != null && !player.isCreative() && !player.isSpectator()) {
                xp += XpUtil.drain(player, Math.min(DRAIN_AMOUNT, MAX_XP - xp));
            }
        }
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, source, recentlyHit);
        if (xp > 0) ExperienceOrb.award(level, position(), xp);
        xp = 0;
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        output.putInt("xp", xp);
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);
        xp = input.getIntOr("xp", 0);
    }
}
