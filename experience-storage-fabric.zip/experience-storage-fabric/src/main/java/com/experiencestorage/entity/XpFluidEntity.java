package com.experiencestorage.entity;

import com.experiencestorage.block.XpPipeBlock;
import com.experiencestorage.block.XpTankBlock;
import com.experiencestorage.block.XpValveBlock;
import com.experiencestorage.blockentity.XpTankBlockEntity;
import com.experiencestorage.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

/**
 * A packet of experience travelling through pipes. It is not drawn; it leaves a
 * trail of green sparkles. When it reaches a tank it is stored, and if it hits a
 * dead end, a closed valve or a full tank the rest is dropped as orbs.
 */
public class XpFluidEntity extends Entity {
    private static final double SPEED = 0.15;
    private static final Direction[] ORDER = {
            Direction.DOWN, Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST, Direction.UP};

    private int amount;
    private Direction heading = Direction.DOWN;
    private BlockPos cell;
    private BlockPos target;

    public XpFluidEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        setNoGravity(true);
    }

    public static void spawn(ServerLevel level, BlockPos pos, int amount, Direction heading) {
        XpFluidEntity e = new XpFluidEntity(ModEntities.XP_FLUID, level);
        Vec3 c = Vec3.atCenterOf(pos);
        e.setPos(c.x, c.y, c.z);
        e.amount = amount;
        e.heading = heading;
        e.cell = pos;
        level.addFreshEntity(e);
    }

    /** Can a packet moving in {@code moving} direction enter the block at {@code pos}? */
    public static boolean canEnter(Level level, BlockPos pos, Direction moving) {
        BlockState s = level.getBlockState(pos);
        Block b = s.getBlock();
        if (b instanceof XpPipeBlock || b instanceof XpTankBlock) return true;
        if (b instanceof XpValveBlock) {
            return s.getValue(XpValveBlock.FACING).getAxis() == moving.getAxis() && !s.getValue(XpValveBlock.BLOCKED);
        }
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (!(level() instanceof ServerLevel serverLevel)) return;
        if (cell == null || amount <= 0) {
            discard();
            return;
        }
        if (target == null) {
            arrive(serverLevel);
            if (isRemoved() || target == null) return;
        }
        Vec3 goal = Vec3.atCenterOf(target);
        Vec3 delta = goal.subtract(position());
        if (delta.length() <= SPEED) {
            setPos(goal.x, goal.y, goal.z);
            cell = target;
            target = null;
        } else {
            Vec3 p = position().add(delta.normalize().scale(SPEED));
            setPos(p.x, p.y, p.z);
        }
        if (tickCount % 2 == 0) {
            serverLevel.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY(), getZ(), 1, 0.05, 0.05, 0.05, 0.0);
        }
    }

    /** Called when the packet sits at the centre of {@code cell}: store it or pick the next direction. */
    private void arrive(ServerLevel level) {
        BlockState state = level.getBlockState(cell);
        if (state.getBlock() instanceof XpTankBlock) {
            if (level.getBlockEntity(cell) instanceof XpTankBlockEntity tank) {
                amount -= tank.addXp(amount);
            }
            level.playSound(null, cell, SoundEvents.BOTTLE_FILL, SoundSource.BLOCKS, 0.3F, 1.4F);
            spill(level);
            return;
        }
        Direction next = null;
        if (state.getBlock() instanceof XpPipeBlock) {
            if (canEnter(level, cell.relative(heading), heading) && state.getValue(XpPipeBlock.CONNECTION.get(heading))) {
                next = heading;
            } else {
                for (Direction d : ORDER) {
                    if (d == heading.getOpposite()) continue;
                    if (state.getValue(XpPipeBlock.CONNECTION.get(d)) && canEnter(level, cell.relative(d), d)) {
                        next = d;
                        break;
                    }
                }
            }
        } else if (state.getBlock() instanceof XpValveBlock && canEnter(level, cell.relative(heading), heading)) {
            next = heading;
        }
        if (next == null) {
            spill(level);
            return;
        }
        heading = next;
        target = cell.relative(next);
    }

    /** Drops whatever is left as normal experience orbs and removes the packet. */
    private void spill(ServerLevel level) {
        if (amount > 0) ExperienceOrb.award(level, position(), amount);
        amount = 0;
        discard();
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {}

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        amount = input.getIntOr("amount", 0);
        heading = Direction.byName(input.getStringOr("heading", "down"));
        if (heading == null) heading = Direction.DOWN;
        cell = blockPosition();
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        output.putInt("amount", amount);
        output.putString("heading", heading.getSerializedName());
    }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float damage) {
        return false;
    }

    @Override
    public boolean isPickable() {
        return false;
    }
}
