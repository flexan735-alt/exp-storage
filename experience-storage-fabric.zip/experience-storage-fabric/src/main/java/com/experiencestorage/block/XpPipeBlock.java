package com.experiencestorage.block;

import com.mojang.serialization.MapCodec;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class XpPipeBlock extends Block {
    public static final MapCodec<XpPipeBlock> CODEC = simpleCodec(XpPipeBlock::new);
    public static final BooleanProperty BLOCKED = BooleanProperty.create("blocked");
    public static final Map<Direction, BooleanProperty> CONNECTION = new EnumMap<>(Direction.class);

    static {
        for (Direction d : Direction.values()) {
            CONNECTION.put(d, BooleanProperty.create(d.getSerializedName()));
        }
    }

    private static final VoxelShape CORE = Block.box(5, 5, 5, 11, 11, 11);
    private static final Map<Direction, VoxelShape> ARMS = new EnumMap<>(Direction.class);

    static {
        ARMS.put(Direction.DOWN, Block.box(5, 0, 5, 11, 5, 11));
        ARMS.put(Direction.UP, Block.box(5, 11, 5, 11, 16, 11));
        ARMS.put(Direction.NORTH, Block.box(5, 5, 0, 11, 11, 5));
        ARMS.put(Direction.SOUTH, Block.box(5, 5, 11, 11, 11, 16));
        ARMS.put(Direction.WEST, Block.box(0, 5, 5, 5, 11, 11));
        ARMS.put(Direction.EAST, Block.box(11, 5, 5, 16, 11, 11));
    }

    public XpPipeBlock(Properties properties) {
        super(properties);
        BlockState state = stateDefinition.any().setValue(BLOCKED, false);
        for (BooleanProperty p : CONNECTION.values()) state = state.setValue(p, false);
        registerDefaultState(state);
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(BLOCKED);
        for (BooleanProperty p : CONNECTION.values()) builder.add(p);
    }

    /** Does a pipe connect to the neighbour that sits in direction {@code toward}? */
    static boolean connects(BlockState neighbour, Direction toward) {
        Block b = neighbour.getBlock();
        if (b instanceof XpPipeBlock || b instanceof XpTankBlock) return true;
        if (b instanceof XpValveBlock) return neighbour.getValue(XpValveBlock.FACING).getAxis() == toward.getAxis();
        if (b instanceof XpExtractorBlock) return toward == Direction.UP;
        return false;
    }

    private static BlockState compute(LevelReader level, BlockPos pos, BlockState state) {
        boolean blocked = false;
        for (Direction d : Direction.values()) {
            BlockState n = level.getBlockState(pos.relative(d));
            state = state.setValue(CONNECTION.get(d), connects(n, d));
            if (n.getBlock() instanceof XpValveBlock
                    && n.getValue(XpValveBlock.FACING).getAxis() == d.getAxis()
                    && n.getValue(XpValveBlock.BLOCKED)) {
                blocked = true;
            }
        }
        return state.setValue(BLOCKED, blocked);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return compute(context.getLevel(), context.getClickedPos(), defaultBlockState());
    }

    @Override
    protected BlockState updateShape(BlockState state, LevelReader level, ScheduledTickAccess ticks, BlockPos pos,
                                     Direction direction, BlockPos neighbourPos, BlockState neighbourState,
                                     RandomSource random) {
        return compute(level, pos, state);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        VoxelShape shape = CORE;
        for (Direction d : Direction.values()) {
            if (state.getValue(CONNECTION.get(d))) shape = Shapes.or(shape, ARMS.get(d));
        }
        return shape;
    }
}
