package com.experiencestorage.block;

import com.experiencestorage.blockentity.XpTankBlockEntity;
import com.experiencestorage.registry.ModBlockEntities;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class XpTankBlock extends BaseEntityBlock {
    public static final MapCodec<XpTankBlock> CODEC = simpleCodec(XpTankBlock::new);
    public static final IntegerProperty FILL = IntegerProperty.create("fill", 0, 14);
    /** Points taken out per glass bottle. */
    private static final int BOTTLE_XP = 8;

    public XpTankBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(FILL, 0));
    }

    public static int fillFor(int xp) {
        if (xp <= 0) return 0;
        return Mth.clamp((int) Math.ceil(xp * 14.0 / XpTankBlockEntity.CAPACITY), 1, 14);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FILL);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new XpTankBlockEntity(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide() ? null
                : createTickerHelper(type, ModBlockEntities.XP_TANK, XpTankBlockEntity::serverTick);
    }

    /** Right-click with a glass bottle to fill an experience bottle. */
    @Override
    protected InteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                          Player player, InteractionHand hand, BlockHitResult hit) {
        if (!stack.is(Items.GLASS_BOTTLE)) return InteractionResult.TRY_WITH_EMPTY_HAND;
        if (!(level.getBlockEntity(pos) instanceof XpTankBlockEntity tank) || tank.getXp() < BOTTLE_XP) {
            return InteractionResult.TRY_WITH_EMPTY_HAND;
        }
        if (!level.isClientSide()) {
            tank.removeXp(BOTTLE_XP);
            if (!player.getAbilities().instabuild) stack.shrink(1);
            ItemStack bottle = new ItemStack(Items.EXPERIENCE_BOTTLE);
            if (!player.getInventory().add(bottle)) player.drop(bottle, false);
            level.playSound(null, pos, SoundEvents.BOTTLE_FILL, SoundSource.BLOCKS, 1.0F, 1.0F);
        }
        return InteractionResult.SUCCESS;
    }

    /** Right-click with an empty hand to see what is stored. */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos,
                                               Player player, BlockHitResult hit) {
        if (!level.isClientSide() && level.getBlockEntity(pos) instanceof XpTankBlockEntity tank) {
            player.displayClientMessage(Component.translatable("message.experience_storage.tank_contents",
                    tank.getXp(), XpTankBlockEntity.CAPACITY), true);
        }
        return InteractionResult.SUCCESS;
    }

    /** Breaking a tank releases the stored experience as orbs. */
    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (level instanceof ServerLevel serverLevel
                && level.getBlockEntity(pos) instanceof XpTankBlockEntity tank && tank.getXp() > 0) {
            ExperienceOrb.award(serverLevel, Vec3.atCenterOf(pos), tank.getXp());
        }
        return super.playerWillDestroy(level, pos, state, player);
    }
}
