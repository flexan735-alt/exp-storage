package com.experiencestorage.block;

import com.experiencestorage.entity.XpFluidEntity;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * A low plate. Mobs that die on it, and players that stand on it, have their
 * experience sent down into the pipe or tank underneath.
 */
public class XpExtractorBlock extends Block {
    public static final MapCodec<XpExtractorBlock> CODEC = simpleCodec(XpExtractorBlock::new);
    private static final VoxelShape SHAPE = Block.box(1, 0, 1, 15, 4, 15);

    public XpExtractorBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    public static boolean canFeed(Level level, BlockPos pos) {
        return XpFluidEntity.canEnter(level, pos.below(), Direction.DOWN);
    }

    /** Sends experience into whatever is below the extractor. Returns false if nothing can take it. */
    public static boolean feed(Level level, BlockPos pos, int amount) {
        if (!(level instanceof ServerLevel serverLevel) || amount <= 0 || !canFeed(level, pos)) return false;
        XpFluidEntity.spawn(serverLevel, pos.below(), amount, Direction.DOWN);
        return true;
    }
}
