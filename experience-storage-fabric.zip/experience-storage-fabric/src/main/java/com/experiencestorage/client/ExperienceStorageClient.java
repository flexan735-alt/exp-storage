package com.experiencestorage.client;

import com.experiencestorage.registry.ModBlocks;
import com.experiencestorage.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.entity.NoopRenderer;

public class ExperienceStorageClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Both entities are shown with particles, so they use an empty renderer.
        EntityRendererRegistry.register(ModEntities.XP_FLUID, NoopRenderer::new);
        EntityRendererRegistry.register(ModEntities.ORB_FAIRY, NoopRenderer::new);

        // Glass-like blocks need the translucent render layer.
        BlockRenderLayerMap.putBlock(ModBlocks.XP_TANK, ChunkSectionLayer.TRANSLUCENT);
        BlockRenderLayerMap.putBlock(ModBlocks.XP_PIPE, ChunkSectionLayer.TRANSLUCENT);
        BlockRenderLayerMap.putBlock(ModBlocks.XP_EXTRACTOR, ChunkSectionLayer.TRANSLUCENT);
        BlockRenderLayerMap.putBlock(ModBlocks.XP_VALVE, ChunkSectionLayer.TRANSLUCENT);
    }
}
