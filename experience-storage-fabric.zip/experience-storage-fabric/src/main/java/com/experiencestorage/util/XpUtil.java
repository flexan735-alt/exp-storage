package com.experiencestorage.util;

import net.minecraft.world.entity.player.Player;

/** Helpers for reading and removing a player's experience in raw points. */
public final class XpUtil {
    /** Total points needed to reach the given level from level 0 (vanilla formula). */
    public static int levelToPoints(int level) {
        if (level <= 16) return level * level + 6 * level;
        if (level <= 31) return (int) (2.5 * level * level - 40.5 * level + 360.0);
        return (int) (4.5 * level * level - 162.5 * level + 2220.0);
    }

    public static int total(Player player) {
        return levelToPoints(player.experienceLevel)
                + Math.round(player.experienceProgress * player.getXpNeededForNextLevel());
    }

    /** Removes up to {@code amount} points from the player and returns how many were removed. */
    public static int drain(Player player, int amount) {
        int n = Math.min(amount, total(player));
        if (n > 0) player.giveExperiencePoints(-n);
        return n;
    }

    private XpUtil() {}
}
