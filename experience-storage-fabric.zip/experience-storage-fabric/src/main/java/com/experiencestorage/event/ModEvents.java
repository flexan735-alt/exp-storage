package com.experiencestorage.event;

import com.experiencestorage.block.XpExtractorBlock;
import com.experiencestorage.entity.OrbFairyEntity;
import com.experiencestorage.registry.ModEntities;
import com.experiencestorage.util.XpUtil;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.world.SpawnRestriction;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.levelgen.Heightmap;

public final class ModEvents {
    /** How often (in ticks) and how much (in points) a player standing on an extractor gives. */
    private static final int PLAYER_INTERVAL = 4;
    private static final int PLAYER_TRANSFER = 5;

    public static void init() {
        // Orb fairy: attributes and natural spawning in the overworld
        FabricDefaultAttributeRegistry.register(ModEntities.ORB_FAIRY, OrbFairyEntity.createAttributes());
        SpawnRestriction.register(ModEntities.ORB_FAIRY, SpawnPlacementTypes.NO_RESTRICTIONS,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (type, level, reason, pos, random) -> true);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), MobCategory.AMBIENT,
                ModEntities.ORB_FAIRY, 10, 1, 1);

        // Experience orbs that appear on top of an extractor (mob deaths) are sent into the pipes instead.
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (!(entity instanceof ExperienceOrb orb)) return;
            BlockPos pos = orb.blockPosition();
            if (!(world.getBlockState(pos).getBlock() instanceof XpExtractorBlock)) return;
            int value = orb.getValue();
            world.getServer().execute(() -> {
                if (!orb.isRemoved() && XpExtractorBlock.feed(world, pos, value)) orb.discard();
            });
        });

        // Players standing on an extractor (not sneaking) pour experience into the pipes.
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTickCount() % PLAYER_INTERVAL != 0) return;
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                if (player.isSpectator() || player.isShiftKeyDown()) continue;
                BlockPos pos = player.blockPosition();
                var level = player.level();
                if (!(level.getBlockState(pos).getBlock() instanceof XpExtractorBlock)) continue;
                if (!XpExtractorBlock.canFeed(level, pos)) continue;
                int taken = XpUtil.drain(player, PLAYER_TRANSFER);
                if (taken > 0 && !XpExtractorBlock.feed(level, pos, taken)) {
                    player.giveExperiencePoints(taken);
                }
            }
        });
    }

    private ModEvents() {}
}
