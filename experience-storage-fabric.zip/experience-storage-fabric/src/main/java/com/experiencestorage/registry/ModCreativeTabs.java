package com.experiencestorage.registry;

import com.experiencestorage.ExperienceStorage;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

public final class ModCreativeTabs {
    public static final CreativeModeTab EXPERIENCE_FLOW = Registry.register(
            BuiltInRegistries.CREATIVE_MODE_TAB, ExperienceStorage.id("experience_flow"),
            FabricItemGroup.builder()
                    .title(Component.translatable("itemGroup.experience_storage.experience_flow"))
                    .icon(() -> new ItemStack(ModItems.XP_TANK))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.XP_TANK);
                        output.accept(ModItems.XP_PIPE);
                        output.accept(ModItems.XP_EXTRACTOR);
                        output.accept(ModItems.XP_VALVE);
                        output.accept(ModItems.ORB_FAIRY_SPAWN_EGG);
                    })
                    .build());

    public static void init() {}
    private ModCreativeTabs() {}
}
