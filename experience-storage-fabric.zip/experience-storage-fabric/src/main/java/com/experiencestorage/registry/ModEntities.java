package com.experiencestorage.registry;

import com.experiencestorage.ExperienceStorage;
import com.experiencestorage.entity.OrbFairyEntity;
import com.experiencestorage.entity.XpFluidEntity;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class ModEntities {
    public static final EntityType<XpFluidEntity> XP_FLUID = register("xp_fluid",
            EntityType.Builder.<XpFluidEntity>of(XpFluidEntity::new, MobCategory.MISC)
                    .sized(0.1F, 0.1F).clientTrackingRange(4).updateInterval(2));
    public static final EntityType<OrbFairyEntity> ORB_FAIRY = register("orb_fairy",
            EntityType.Builder.<OrbFairyEntity>of(OrbFairyEntity::new, MobCategory.AMBIENT)
                    .sized(0.5F, 0.5F).clientTrackingRange(8));

    private static <T extends Entity> EntityType<T> register(String name, EntityType.Builder<T> builder) {
        ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, ExperienceStorage.id(name));
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
    }

    public static void init() {}
    private ModEntities() {}
}
