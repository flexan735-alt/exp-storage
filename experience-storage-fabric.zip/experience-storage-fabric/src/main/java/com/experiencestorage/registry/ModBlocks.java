package com.experiencestorage.registry;

import com.experiencestorage.ExperienceStorage;
import com.experiencestorage.block.XpExtractorBlock;
import com.experiencestorage.block.XpPipeBlock;
import com.experiencestorage.block.XpTankBlock;
import com.experiencestorage.block.XpValveBlock;
import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

public final class ModBlocks {
    public static final Block XP_TANK = register("xp_tank", XpTankBlock::new,
            BlockBehaviour.Properties.of().strength(1.0F).sound(SoundType.GLASS).noOcclusion());
    public static final Block XP_PIPE = register("xp_pipe", XpPipeBlock::new,
            BlockBehaviour.Properties.of().strength(0.6F).sound(SoundType.GLASS).noOcclusion());
    public static final Block XP_EXTRACTOR = register("xp_extractor", XpExtractorBlock::new,
            BlockBehaviour.Properties.of().strength(1.0F).sound(SoundType.GLASS).noOcclusion());
    public static final Block XP_VALVE = register("xp_valve", XpValveBlock::new,
            BlockBehaviour.Properties.of().strength(0.6F).sound(SoundType.GLASS).noOcclusion());

    private static Block register(String name, Function<BlockBehaviour.Properties, Block> factory,
                                  BlockBehaviour.Properties props) {
        ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, ExperienceStorage.id(name));
        Block block = factory.apply(props.setId(key));
        return Registry.register(BuiltInRegistries.BLOCK, key, block);
    }

    public static void init() {}
    private ModBlocks() {}
}
