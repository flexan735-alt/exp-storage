package com.experiencestorage.registry;

import com.experiencestorage.ExperienceStorage;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.level.block.Block;

public final class ModItems {
    public static final Item XP_TANK = blockItem("xp_tank", ModBlocks.XP_TANK);
    public static final Item XP_PIPE = blockItem("xp_pipe", ModBlocks.XP_PIPE);
    public static final Item XP_EXTRACTOR = blockItem("xp_extractor", ModBlocks.XP_EXTRACTOR);
    public static final Item XP_VALVE = blockItem("xp_valve", ModBlocks.XP_VALVE);
    public static final Item ORB_FAIRY_SPAWN_EGG = spawnEgg();

    private static Item blockItem(String name, Block block) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, ExperienceStorage.id(name));
        Item item = new BlockItem(block, new Item.Properties().setId(key).useBlockDescriptionPrefix());
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    private static Item spawnEgg() {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, ExperienceStorage.id("orb_fairy_spawn_egg"));
        Item item = new SpawnEggItem(new Item.Properties().setId(key).spawnEgg(ModEntities.ORB_FAIRY));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    public static void init() {}
    private ModItems() {}
}
