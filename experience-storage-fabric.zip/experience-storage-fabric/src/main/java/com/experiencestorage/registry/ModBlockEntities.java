package com.experiencestorage.registry;

import com.experiencestorage.ExperienceStorage;
import com.experiencestorage.blockentity.XpTankBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.entity.BlockEntityType;

public final class ModBlockEntities {
    public static final BlockEntityType<XpTankBlockEntity> XP_TANK = Registry.register(
            BuiltInRegistries.BLOCK_ENTITY_TYPE, ExperienceStorage.id("xp_tank"),
            FabricBlockEntityTypeBuilder.create(XpTankBlockEntity::new, ModBlocks.XP_TANK).build());

    public static void init() {}
    private ModBlockEntities() {}
}
