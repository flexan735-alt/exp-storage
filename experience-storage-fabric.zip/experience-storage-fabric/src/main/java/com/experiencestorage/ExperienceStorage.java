package com.experiencestorage;

import com.experiencestorage.event.ModEvents;
import com.experiencestorage.registry.ModBlockEntities;
import com.experiencestorage.registry.ModBlocks;
import com.experiencestorage.registry.ModCreativeTabs;
import com.experiencestorage.registry.ModEntities;
import com.experiencestorage.registry.ModItems;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;

public class ExperienceStorage implements ModInitializer {
    public static final String MOD_ID = "experience_storage";

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModBlockEntities.init();
        ModEntities.init();
        ModItems.init();
        ModCreativeTabs.init();
        ModEvents.init();
    }
}
