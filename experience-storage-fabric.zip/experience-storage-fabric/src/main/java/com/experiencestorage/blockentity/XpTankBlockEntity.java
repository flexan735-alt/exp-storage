package com.experiencestorage.blockentity;

import com.experiencestorage.block.XpTankBlock;
import com.experiencestorage.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

public class XpTankBlockEntity extends BlockEntity {
    /** Experience points a tank holds (same as reaching level 40). */
    public static final int CAPACITY = 2920;
    /** Points a tank pushes into the tank below it each second. */
    public static final int TRANSFER = 160;

    private int xp;

    public XpTankBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.XP_TANK, pos, state);
    }

    public int getXp() {
        return xp;
    }

    /** Adds points, returns how many were accepted. */
    public int addXp(int amount) {
        int accepted = Mth.clamp(amount, 0, CAPACITY - xp);
        if (accepted > 0) {
            xp += accepted;
            onChanged();
        }
        return accepted;
    }

    /** Removes points, returns how many were removed. */
    public int removeXp(int amount) {
        int removed = Mth.clamp(amount, 0, xp);
        if (removed > 0) {
            xp -= removed;
            onChanged();
        }
        return removed;
    }

    private void onChanged() {
        setChanged();
        if (level == null) return;
        BlockState state = getBlockState();
        int fill = XpTankBlock.fillFor(xp);
        if (state.getValue(XpTankBlock.FILL) != fill) {
            level.setBlock(worldPosition, state.setValue(XpTankBlock.FILL, fill), 3);
        }
    }

    @Override
    protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        output.putInt("xp", xp);
    }

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        xp = input.getIntOr("xp", 0);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, XpTankBlockEntity tank) {
        if (tank.xp <= 0 || level.getGameTime() % 20 != 0) return;
        if (level.getBlockEntity(pos.below()) instanceof XpTankBlockEntity below) {
            int accepted = below.addXp(Math.min(TRANSFER, tank.xp));
            tank.removeXp(accepted);
        }
    }
}
