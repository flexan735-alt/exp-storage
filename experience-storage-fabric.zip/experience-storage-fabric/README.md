# Experience Storage (Fabric 1.21.11 remake)

Remake of the "Experience Storage" Forge 1.20.1 mod for Fabric 1.21.11.

- **Experience tank** - holds 2920 XP (level 40). Right-click to see contents, right-click with a glass bottle to fill an experience bottle (8 XP). Pushes XP into a tank directly below it. Breaking it releases the XP as orbs.
- **Experience pipe** - connects to pipes, tanks, valves and extractors.
- **Experience valve** - right-click to open/close.
- **Experience extractor** - mobs that die on it and players standing on it (not sneaking) send XP down into the pipe/tank under it.
- **Orb fairy** - small flying spirit (spawns in the overworld, has a spawn egg). Siphons XP from nearby players, flees when hurt, drops its XP when killed.

## Getting the jar (no coding needed)
1. Put all these files in your GitHub repo (keep the folders as they are, including `.github`).
2. Open the repo's **Actions** tab, open the newest "Build mod" run.
3. When it is green, download **experience-storage-fabric-jar** at the bottom of the page. Unzip it; the `.jar` without `-sources` goes in your `mods` folder together with Fabric API.
4. If the run is red, open it, copy the error text and send it to Claude.
